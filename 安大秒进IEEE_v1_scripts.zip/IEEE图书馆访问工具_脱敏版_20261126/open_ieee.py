"""Open the library IEEE Xplore page in Edge.

Already logged in: go straight to IEEE.
Login form: sign in.
Expired session: log out, then sign in again.
"""
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "pydeps"))

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[logging.FileHandler(ROOT / "ieee-automation.log", encoding="utf-8"), logging.StreamHandler()])
logging.info("Starting Playwright automation")
from playwright.sync_api import sync_playwright

IEEE_URL = "https://wvpn.ahu.edu.cn/https/77726476706e69737468656265737421f9f244993f20645f6c0dc7a59d50267b1ab4a9/"
ACCOUNT_FILE = ROOT / "account.txt"
PROFILE = ROOT / "edge-profile"
DEBUG_PORT = 9333


def read_account():
    """Use optional local credentials; otherwise prompt without saving them."""
    import getpass
    values = {}
    if ACCOUNT_FILE.exists():
        for line in ACCOUNT_FILE.read_text(encoding="utf-8-sig").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                values[key.strip().lower()] = value.strip()
    username = values.get("username", "") or input("学校账号 / Username: ").strip()
    password = values.get("password", "") or getpass.getpass("学校密码 / Password (hidden): ")
    if not username or not password:
        raise RuntimeError("Account or password is empty.")
    return username, password


def login_visible(page):
    box = page.locator('input[placeholder="用户名"]')
    return box.count() > 0 and box.first.is_visible()


def expired(page):
    note = page.get_by_text("登录状态过期")
    return note.count() > 0 and note.first.is_visible()


def on_ieee(page):
    title = page.title().lower()
    if "unable to load" in title or "unusual traffic" in title:
        return False
    try:
        body = page.locator("body").inner_text(timeout=1500).lower()
    except Exception:
        body = ""
    # 学校 WebVPN 的网址是编码后的代理地址，里面没有 ieeexplore。
    return "ieee xplore" in title or "ieee xplore" in body or "ieeexplore.ieee.org" in body


def token_rejected(page):
    note = page.get_by_text("非法token")
    return note.count() > 0 and note.first.is_visible()


def sign_in(page):
    username, password = read_account()
    page.locator("#index_login_btn").wait_for(state="visible", timeout=10000)
    page.locator('input[placeholder="用户名"]').first.fill(username)
    page.locator('input[placeholder="密码"]').first.fill(password)
    page.locator("#index_login_btn").click()


def log_out(page):
    page.evaluate(
        """() => {
            const account = document.getElementById('user-btn-01');
            if (account) account.click();
            const box = document.querySelector('.user-info-box.menu-fr');
            const link = box && [...box.querySelectorAll('a')].find(item => item.innerText.trim() === '注销');
            if (link) link.click();
        }"""
    )


def reach_ieee(page):
    page.goto(IEEE_URL, wait_until="domcontentloaded", timeout=60000)
    submitted = False
    for _ in range(25):
        page.wait_for_timeout(1000)
        if on_ieee(page):
            return
        if expired(page):
            log_out(page)
            submitted = False
            page.wait_for_timeout(1500)
            continue
        if token_rejected(page):
            page.reload(wait_until="domcontentloaded")
            submitted = False
            continue
        if login_visible(page):
            if not submitted:
                sign_in(page)
                submitted = True
            continue
        submitted = False
        if "tp_up/view" in page.url:
            page.goto(IEEE_URL, wait_until="domcontentloaded", timeout=60000)
    raise RuntimeError(f"未能进入 IEEE。当前标题：{page.title()}；网址：{page.url}")


def edge_executable():
    import os
    candidates = [
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    ]
    if os.environ.get("LOCALAPPDATA"):
        candidates.append(Path(os.environ["LOCALAPPDATA"]) / "Microsoft/Edge/Application/msedge.exe")
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise RuntimeError("没有找到 Microsoft Edge。")


def debugging_ready():
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{DEBUG_PORT}/json/version", timeout=1) as response:
            return response.status == 200
    except Exception:
        return False


def start_edge():
    if debugging_ready():
        return
    PROFILE.mkdir(exist_ok=True)
    import subprocess
    subprocess.Popen(
        [
            str(edge_executable()),
            f"--remote-debugging-port={DEBUG_PORT}",
            f"--user-data-dir={PROFILE}",
            "--new-window",
            "about:blank",
        ],
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_BREAKAWAY_FROM_JOB,
        close_fds=True,
    )
    for _ in range(40):
        if debugging_ready():
            return
        time.sleep(0.25)
    raise RuntimeError("Edge 已启动，但调试端口没有就绪。")


def main():
    start_edge()
    with sync_playwright() as playwright:
        browser = playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{DEBUG_PORT}")
        context = browser.contexts[0]
        page = context.pages[0] if context.pages else context.new_page()
        reach_ieee(page)
        print("IEEE 已打开，脚本结束，浏览器保持打开。")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        logging.error("IEEE automation failed; error type: %s", type(sys.exc_info()[1]).__name__)
        sys.exit(1)
