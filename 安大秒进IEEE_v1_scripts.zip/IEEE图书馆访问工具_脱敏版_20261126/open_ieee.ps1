param([switch]$CheckOnly)
$ErrorActionPreference='Stop'
$log=Join-Path $PSScriptRoot 'ieee-launch.log'
$python=Join-Path $PSScriptRoot 'runtime\python.exe'
$loginScript=Join-Path $PSScriptRoot 'open_ieee.py'
try {
 $candidates=@()
 if(${env:ProgramFiles(x86)}){$candidates+=(Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe')}
 if($env:ProgramFiles){$candidates+=(Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')}
 if($env:LOCALAPPDATA){$candidates+=(Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')}
 $browser=$candidates | Where-Object {Test-Path -LiteralPath $_} | Select-Object -First 1
 if(-not $browser){throw 'Microsoft Edge executable not found.'}
 Add-Content -LiteralPath $log -Value ((Get-Date -Format o)+' Browser found: '+$browser) -Encoding utf8
 if($CheckOnly){Write-Output ('CHECK_OK: '+$browser);exit 0}
 if(-not (Test-Path -LiteralPath $python)){throw 'Python executable not found.'}
 if(-not (Test-Path -LiteralPath $loginScript)){throw 'Login script not found.'}
 Add-Content -LiteralPath $log -Value ((Get-Date -Format o)+' Starting automatic sign-in.') -Encoding utf8
 $env:PYTHONIOENCODING='utf-8'
 & $python -u $loginScript
 if($LASTEXITCODE -ne 0){throw ('Automatic sign-in exited with code '+$LASTEXITCODE)}
 Add-Content -LiteralPath $log -Value ((Get-Date -Format o)+' Automatic sign-in finished.') -Encoding utf8
 exit 0
} catch {
 Add-Content -LiteralPath $log -Value ((Get-Date -Format o)+' ERROR: '+$_.Exception.Message) -Encoding utf8
 Write-Host ('Launch failed: '+$_.Exception.Message) -ForegroundColor Red
 Write-Host ('Log file: '+$log)
 exit 1
}
